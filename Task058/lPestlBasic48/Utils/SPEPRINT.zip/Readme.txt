Whohooo! We've made it to Version 1.0.

SpecPrint is a program that allows you to view and/or print BASIC listings from the ZX Spectrum (And since version 0.0.0.2 ZX81).  Simply save a snapshot from your favourite emulator and load it into  SpecPrint.  SpecPrint retains all attributes contained in the listing including foreground colour, background colour, bright, flashing[1], inverse etc.  It also uses a font similar to the original machine containing all the block characters and grey blocks of the ZX81.

[1] Flashing is represented by italic text - it would be a little difficult to get actual printed text to flash on a piece of paper.

Supported formats

Specprint supports the following Spectrum formats .Z80, .SNA, .SP, .ZX, plus the .P format for ZX81 programs.

Limitations

Although SpecPrint will load snapshots taken from a 128K program without difficulty, it currently does not handle the "SPECTRUM" and "PLAY" keywords.  There may be other issues with 128K programs that I am not aware of.

Changes in version 1.0:

 - You can now edit the colours used to represent the 16 Speccy and 2 ZX81 colours.
 - If "Fixed Line Length" is not selected, SpecPrint will now reformat the listing to match the width of the page when printing.
 - Another option, "Split multi-statement lines" puts each new statement on a new line.  It makes things like game loaders and the like far more readable.
 - more bugs killed.  How many more can there be?

Changes in version 0.0.0.6:

 - The font has changed again :(
 - Specprint doesn't go back to the start of the listing whenever you resize the window or make any changes.  The code would probably get hideously confused if there was a listing containing two lines with the same line number though (It is possible...).
 - Several more bugs caught, and probably numerous more introduced.
 - I've actually drawn some icons for it now, though they're not the most inventive around.
 - SpecPrint now actually prints! Yes, the moment you've all been waiting for - you can now print directly from SpecPrint.  Well you should anyway because I haven't been able to test it yet. I seem to have lost all my kettle leads so I can't plug the printer in to test it.
 - The program size.  It's upto a megabyte now, just for a simple little program like this.... I blame Borland.... and Microsoft.... and whoever else I can think of....

Hmm, just discovered a nasty bug. It appears the program crashes and won't run unless the machine it's on has a printer installed.  I'll have to see what I can do about this one.

Changes in version 0.0.0.5:

 - Version No. in about box updates (Whoops).
 - Another Change to the font.  This time it's just a little bit of tidying up - the ZX81 Grey blocks didn't quite line up with the other graphics characters properly.
 - Added "Word import" and "View RTF Source", though the word option only probably works for Office 97 at the moment - feedback would be appreciated. "View Source" is more a debugging feature for my use than anything else.
 - Finally fixed the line wrapping (Probably....).
 - More options saved when exiting.
 - Several other bugs fixed.


Changes in version 0.0.0.4:

 - Rearranged Menu
 - Added ability to Change the font size.
 - Fixed the line wrapping (again)
 - The program now saves its default values on exit
 - I've merged the two fonts into one file.  Only the (new) ZX Spectrum.TTF is now required.  It should also fix some bugs with the kerning table.
 - Even more bugs squashed...

Changes in version 0.0.0.3:

 - The font has changed again.
 - Numerous bugs fixed
 - "Display actual number" now displays the correct number
 - Various display options added
 - You can now export direct to Wordpad
 - SpecPrint now detects snapshots with invalid system variables and does not crash while trying to display a nonexistant BASIC program (hopefully).

Changes in version 0.0.0.2:

 - SpecPrint Loads ZX81 .P files.
 - Changes to the font to support the ZX81 grey block characters.
 - You can now actually save a .RTF file to disk.

Bugs

There are probably hundreds of bugs left in the program.  Please report any you find to mikeywyn@hotmail.com - I'm in the process of changing ISPs so my permanent email address is likely to change in the next few weeks....

Acknowledgements.

A big thankyou to Alexander Obukhov For his RichEdit98 component.

Also, G M Wolsink (http://www.casema.net.~wolsink) for the RichPrinter component.

And since this is only the second C++Builder application I've ever written, thanks must go to Mr Paul 'Dunny' Dunn for his advice on doing things the Borland/Delphi way...

Actually though, this isn't really a C++Builder application.  It's an ANSI C command line app. with a BCB front end welded on top - look out for the commandline version comming soon (It's only about 40K long too.)

Installation:

Install ZX Spectrum.TTF to the windows\fonts directory, then run the program from where you want.

Note: I have not designed the ZX Spectrum.TTF font.  I downloaded it from WOS and am currently using it until I've drawn my own font which includes characters for the <32 codes, graphics blocks and UDGs. (I hope the author doesn't mind me using it for the time being.)

Please also note that I have included 2 programs which I have not written and of which I do not own the copyright.  3D Monster Maze for the ZX81, and Autochef for the ZX Spectrum.  These are included only to demonstrate SpecPrint and are not in any way to be considered part of the program.

SpecPrint is now considered ShareWare.  If you have a wife/girlfriend you should consider sharing them with the author[1].  If you are female or grossly offended by this statement please feel free to completely ignore it and use the program anyway.








































[1] Only kidding...

Mike W
